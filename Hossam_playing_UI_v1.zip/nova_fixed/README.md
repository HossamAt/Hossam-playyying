# Hossam playing

Android Discord Rich Presence app for OneState servers.

## User flow
- User selects a server from the fixed list.
- User can only start/stop/reconnect Rich Presence.
- Presence is fixed to `OneState`, `Server : <server>`, `by Hossamat`.
- Server logos are loaded from the configured public image/CDN URLs.
- Discord community button opens https://discord.gg/DK4ZRHB4g
- Foreground service refreshes presence every 20 seconds.
- Presence start timestamp is preserved across refreshes so the timer does not reset every 20 seconds.

## Build
Use the GitHub Actions workflow from the previous project with Gradle 8.9, Java 17, Android SDK 35 and NDK 27.3.13750724.
