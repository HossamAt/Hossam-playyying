#include <jni.h>
#include <android/log.h>
#include <memory>
#include <mutex>
#include <ctime>
#include <string>
#include <thread>
#include <atomic>
#include <chrono>
#include "discordpp.h"

#define TAG "NovaPresence"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::shared_ptr<discordpp::Client> g_client;
static std::mutex g_mutex;
static uint64_t g_appId = 1549333944686612570ULL;
static JavaVM* g_vm = nullptr;
static std::atomic<bool> g_callbacksRunning{false};
static std::thread g_callbackThread;

static JNIEnv* getEnv(bool* attached) {
    *attached = false;
    if (!g_vm) return nullptr;
    JNIEnv* env = nullptr;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_EDETACHED) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return nullptr;
        *attached = true;
    }
    return env;
}

static void notifyJava(const char* type, const std::string& message) {
    bool attached = false;
    JNIEnv* env = getEnv(&attached);
    if (!env) return;
    jclass cls = env->FindClass("com/nova/discordpresence/NativeBridge");
    if (!cls) return;
    jmethodID mid = env->GetStaticMethodID(cls, "onNativeEvent", "(Ljava/lang/String;Ljava/lang/String;)V");
    if (!mid) return;
    jstring jt = env->NewStringUTF(type);
    jstring jm = env->NewStringUTF(message.c_str());
    env->CallStaticVoidMethod(cls, mid, jt, jm);
    env->DeleteLocalRef(jt);
    env->DeleteLocalRef(jm);
    env->DeleteLocalRef(cls);
    if (attached) g_vm->DetachCurrentThread();
}

extern "C" jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_nova_discordpresence_NativeBridge_init(JNIEnv*, jobject, jobject, jlong appId) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_appId = static_cast<uint64_t>(appId);

    if (!g_client) {
        g_client = std::make_shared<discordpp::Client>();
        g_client->AddLogCallback(
            [](auto msg, auto severity) { LOGI("%s", msg.c_str()); },
            discordpp::LoggingSeverity::Info);
        g_client->SetApplicationId(g_appId);

        g_callbacksRunning.store(true);
        g_callbackThread = std::thread([] {
            while (g_callbacksRunning.load()) {
                discordpp::RunCallbacks();
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            }
        });
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_nova_discordpresence_NativeBridge_startPresence(
        JNIEnv* env, jobject, jstring jname, jstring jdetails, jstring jstate,
        jstring jlargeImage, jstring jlargeText, jstring jsmallImage, jstring jsmallText, jlong jstartEpoch) {

    const char* name = env->GetStringUTFChars(jname, nullptr);
    const char* details = env->GetStringUTFChars(jdetails, nullptr);
    const char* state = env->GetStringUTFChars(jstate, nullptr);
    const char* largeImage = env->GetStringUTFChars(jlargeImage, nullptr);
    const char* largeText = env->GetStringUTFChars(jlargeText, nullptr);
    const char* smallImage = env->GetStringUTFChars(jsmallImage, nullptr);
    const char* smallText = env->GetStringUTFChars(jsmallText, nullptr);

    std::lock_guard<std::mutex> lock(g_mutex);

    if (!g_client) {
        notifyJava("ERROR", "Discord client is not initialized");
        env->ReleaseStringUTFChars(jname, name);
        env->ReleaseStringUTFChars(jdetails, details);
        env->ReleaseStringUTFChars(jstate, state);
        env->ReleaseStringUTFChars(jlargeImage, largeImage);
        env->ReleaseStringUTFChars(jlargeText, largeText);
        env->ReleaseStringUTFChars(jsmallImage, smallImage);
        env->ReleaseStringUTFChars(jsmallText, smallText);
        return JNI_FALSE;
    }

    discordpp::Activity activity;
    activity.SetType(discordpp::ActivityTypes::Playing);
    activity.SetName(name);
    activity.SetDetails(details);
    activity.SetState(state);

    discordpp::ActivityAssets assets;
    if (largeImage[0] != '\0') assets.SetLargeImage(largeImage);
    if (largeText[0] != '\0') assets.SetLargeText(largeText);
    if (smallImage[0] != '\0') assets.SetSmallImage(smallImage);
    if (smallText[0] != '\0') assets.SetSmallText(smallText);
    activity.SetAssets(assets);

    discordpp::ActivityTimestamps timestamps;
    timestamps.SetStart(static_cast<uint64_t>(jstartEpoch > 0 ? jstartEpoch : static_cast<jlong>(std::time(nullptr))));
    activity.SetTimestamps(timestamps);

    g_client->UpdateRichPresence(std::move(activity), [](discordpp::ClientResult result) {
        notifyJava(result.Successful() ? "PRESENCE_OK" : "PRESENCE_ERROR", result.ToString());
    });

    env->ReleaseStringUTFChars(jname, name);
    env->ReleaseStringUTFChars(jdetails, details);
    env->ReleaseStringUTFChars(jstate, state);
    env->ReleaseStringUTFChars(jlargeImage, largeImage);
    env->ReleaseStringUTFChars(jlargeText, largeText);
    env->ReleaseStringUTFChars(jsmallImage, smallImage);
    env->ReleaseStringUTFChars(jsmallText, smallText);

    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nova_discordpresence_NativeBridge_stopPresence(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_client) g_client->ClearRichPresence();
}

extern "C" JNIEXPORT void JNICALL
Java_com_nova_discordpresence_NativeBridge_shutdown(JNIEnv*, jobject) {
    g_callbacksRunning.store(false);
    if (g_callbackThread.joinable()) g_callbackThread.join();
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_client) {
        g_client->ClearRichPresence();
        g_client.reset();
    }
}
