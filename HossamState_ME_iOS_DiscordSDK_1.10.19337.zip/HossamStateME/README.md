# Hossam State ME — iOS / GitHub

Converted from the current Android `Hossam_State_AUTO_RECONNECT_PERSISTENT_TIMER` project.

Includes the same Discord application ID, activity text, community link, 24 ME servers and image URLs, persistent timer/session storage, reconnect/restore logic, and a SwiftUI interface.

## Discord iOS integration
Discord Social SDK supports iOS 15.1+. On iOS, Rich Presence requires Discord account linking first. The required mobile redirect URI is:

`discord-1549333944686612570:/authorize/callback`

The Android ZIP does not contain the official iOS SDK binary, so it is not fabricated or replaced with an unofficial implementation. Add the official Discord Social SDK under `Vendor/DiscordSocialSDK/` and connect it in Xcode. Then complete the calls marked in `DiscordSDKBridge.swift` using the official `Client::Authorize`, token/connection flow, and `UpdateRichPresence`.

The persistent timestamp is already implemented: the saved `startEpoch` is reused for the same server across app relaunches/reconnects.

## GitHub Actions
`.github/workflows/build.yml` builds the SwiftUI project on a macOS runner. Signing is intentionally not configured because Apple signing credentials belong to your Apple Developer account.
