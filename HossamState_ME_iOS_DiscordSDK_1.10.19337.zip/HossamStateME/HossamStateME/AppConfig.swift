import Foundation

struct Server: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let imageURL: String
}

enum AppConfig {
    static let applicationID: UInt64 = 1549333944686612570
    static let discordCommunityURL = URL(string: "https://discord.gg/DK4ZRHB4g")!
    static let callbackScheme = "discord-1549333944686612570"
    static let appName = "Hossam State ME"
    static let activityName = "OneState"
    static let state = "by Hossamat"

    static let servers: [Server] = [
        Server(name: "Alameda ME", imageURL: "https://cdn.discordapp.com/emojis/1346557146409472070.png"),
        Server(name: "Barry ME", imageURL: "https://cdn.discordapp.com/emojis/1412049991991820358.png"),
        Server(name: "Bell ME", imageURL: "https://cdn.discordapp.com/emojis/1341057206140801085.png"),
        Server(name: "Chico ME", imageURL: "https://cdn.discordapp.com/emojis/1341057490258886721.png"),
        Server(name: "Covina ME", imageURL: "https://cdn.discordapp.com/emojis/1341057310981619784.png"),
        Server(name: "Forest ME", imageURL: "https://cdn.discordapp.com/emojis/1389265233553522778.png"),
        Server(name: "Fortuna ME", imageURL: "https://cdn.discordapp.com/emojis/1364572804250472448.png"),
        Server(name: "Glendale ME", imageURL: "https://f.top4top.io/p_3910rgmcv0.png"),
        Server(name: "Hemet ME", imageURL: "https://cdn.discordapp.com/emojis/1412049963973738596.png"),
        Server(name: "Hills ME", imageURL: "https://cdn.discordapp.com/emojis/1341057349087002735.png"),
        Server(name: "Homeland ME", imageURL: "https://cdn.discordapp.com/emojis/1343966484333989970.png"),
        Server(name: "Laguna ME", imageURL: "https://cdn.discordapp.com/emojis/1341057622941634671.png"),
        Server(name: "Lincoln ME", imageURL: "https://cdn.discordapp.com/emojis/1356278039570415867.png"),
        Server(name: "Lomita ME", imageURL: "https://cdn.discordapp.com/emojis/1341057167804858369.png"),
        Server(name: "Lynwood ME", imageURL: "https://cdn.discordapp.com/emojis/1341057244707422308.png"),
        Server(name: "Madera ME", imageURL: "https://cdn.discordapp.com/emojis/1350846504079855647.png"),
        Server(name: "Malibu ME", imageURL: "https://cdn.discordapp.com/emojis/1487960389982486648.png"),
        Server(name: "Mesa ME", imageURL: "https://cdn.discordapp.com/emojis/1341057580209799260.png"),
        Server(name: "Napa ME", imageURL: "https://cdn.discordapp.com/emojis/1341057528842289235.png"),
        Server(name: "Orange ME", imageURL: "https://b.top4top.io/p_3910rj4y80.png"),
        Server(name: "Redland ME", imageURL: "https://d.top4top.io/p_39104dukk0.png"),
        Server(name: "Solano ME", imageURL: "https://k.top4top.io/p_39104u11a0.png"),
        Server(name: "Wasco ME", imageURL: "https://e.top4top.io/p_3910qazz50.png"),
        Server(name: "Yuba ME", imageURL: "https://g.top4top.io/p_3910scuj90.png")
    ]
}
