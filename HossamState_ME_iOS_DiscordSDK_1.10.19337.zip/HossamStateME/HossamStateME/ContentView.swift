import SwiftUI

struct ContentView: View {
    @StateObject private var store = PresenceStore.shared
    @State private var selectedServer = AppConfig.servers.first(where: { $0.name == "Glendale ME" })!
    @State private var now = Date()

    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            Image("app_background")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.55).ignoresSafeArea())

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    Text(AppConfig.appName)
                        .font(.system(size: 29, weight: .bold))
                        .foregroundStyle(.white)
                    Text("تطوير Hossamat")
                        .font(.system(size: 12))
                        .foregroundStyle(.white.opacity(0.68))

                    Link(destination: AppConfig.discordCommunityURL) {
                        Label("مجتمع الديسكورد", systemImage: "bubble.left.and.bubble.right.fill")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 18)
                            .frame(height: 42)
                            .background(.white.opacity(0.10), in: Capsule())
                            .overlay(Capsule().stroke(.white.opacity(0.12)))
                    }

                    VStack(spacing: 10) {
                        HStack {
                            Circle().fill(store.active ? Color.green : Color.gray).frame(width: 10, height: 10)
                            Text(store.statusText).foregroundStyle(.white.opacity(0.82))
                            Spacer()
                            Text(store.elapsedString(now: now))
                                .monospacedDigit()
                                .foregroundStyle(.white)
                        }
                        Divider().overlay(.white.opacity(0.10))
                        HStack {
                            Text("السيرفر:").foregroundStyle(.white.opacity(0.55))
                            Spacer()
                            Text(store.serverName).foregroundStyle(.white)
                        }
                    }
                    .padding(16)
                    .background(.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 18))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.08)))

                    Button {
                        if store.active { store.stop() } else { store.start(server: selectedServer) }
                    } label: {
                        Text(store.active ? "إيقاف الاتصال" : "اتصال")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity).frame(height: 48)
                            .background(store.active ? Color.white.opacity(0.13) : Color.blue.opacity(0.65), in: RoundedRectangle(cornerRadius: 14))
                    }

                    Button {
                        store.reconnect()
                    } label: {
                        Label("إعادة الاتصال", systemImage: "arrow.clockwise")
                            .foregroundStyle(.white.opacity(0.88))
                            .frame(maxWidth: .infinity).frame(height: 44)
                            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                    }

                    HStack {
                        Text("سيرفرات الشرق الأوسط")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                        Spacer()
                    }
                    .padding(.top, 4)

                    LazyVStack(spacing: 8) {
                        ForEach(AppConfig.servers) { server in
                            Button {
                                selectedServer = server
                                if store.active { store.changeServer(to: server) }
                            } label: {
                                HStack(spacing: 12) {
                                    AsyncImage(url: URL(string: server.imageURL)) { phase in
                                        switch phase {
                                        case .success(let image): image.resizable().scaledToFill()
                                        default: Image(systemName: "gamecontroller.fill").foregroundStyle(.white.opacity(0.55))
                                        }
                                    }
                                    .frame(width: 42, height: 42)
                                    .clipShape(RoundedRectangle(cornerRadius: 11))

                                    Text(server.name)
                                        .foregroundStyle(.white)
                                        .font(.system(size: 14, weight: .medium))
                                    Spacer()
                                    if server == selectedServer {
                                        Image(systemName: "checkmark.circle.fill").foregroundStyle(.blue)
                                    }
                                }
                                .padding(.horizontal, 12)
                                .frame(height: 58)
                                .background(.black.opacity(server == selectedServer ? 0.38 : 0.25), in: RoundedRectangle(cornerRadius: 15))
                                .overlay(RoundedRectangle(cornerRadius: 15).stroke(.white.opacity(server == selectedServer ? 0.16 : 0.06)))
                            }
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 22)
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onReceive(timer) { now = $0 }
        .onAppear {
            if let active = AppConfig.servers.first(where: { $0.name == store.serverName }) { selectedServer = active }
        }
    }
}

#Preview { ContentView() }
