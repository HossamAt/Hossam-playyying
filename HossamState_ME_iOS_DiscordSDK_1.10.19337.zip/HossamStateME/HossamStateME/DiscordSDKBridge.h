#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DiscordSDKBridgeNative : NSObject
+ (instancetype)shared;
- (void)initializeSDK;
- (void)beginAccountLinking;
- (void)updatePresenceWithServerName:(NSString *)serverName
                            imageURL:(NSString *)imageURL
                          startEpoch:(long long)startEpoch;
- (void)reconnectWithServerName:(NSString *)serverName
                       imageURL:(NSString *)imageURL
                     startEpoch:(long long)startEpoch;
- (void)clearPresence;
- (BOOL)isReady;
@end

NS_ASSUME_NONNULL_END
