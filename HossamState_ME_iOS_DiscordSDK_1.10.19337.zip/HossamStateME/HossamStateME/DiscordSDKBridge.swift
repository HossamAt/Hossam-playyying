import Foundation

/// Swift-facing wrapper around the official Discord Social SDK 1.10.19337.
final class DiscordSDKBridge {
    static let shared = DiscordSDKBridge()
    private let native = DiscordSDKBridgeNative.shared()

    private(set) var isReady = false

    private init() {
        native.initializeSDK()
        isReady = native.isReady()
    }

    func beginAccountLinking() {
        native.initializeSDK()
        native.beginAccountLinking()
    }

    func updatePresence(server: Server, startEpoch: Int64) {
        native.updatePresence(withServerName: server.name, imageURL: server.imageURL, startEpoch: startEpoch)
    }

    func reconnect(server: Server, startEpoch: Int64) {
        native.reconnect(withServerName: server.name, imageURL: server.imageURL, startEpoch: startEpoch)
    }

    func clearPresence() {
        native.clearPresence()
    }
}
