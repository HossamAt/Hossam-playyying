#import "DiscordSDKBridge.h"

#define DISCORDPP_IMPLEMENTATION
#import <discord_partner_sdk/discordpp.h>

#import <Security/Security.h>
#include <chrono>
#include <mutex>
#include <thread>

static constexpr uint64_t kApplicationId = 1549333944686612570ULL;
static NSString * const kAccessKey = @"com.nova.hossamstateme.discord.access";
static NSString * const kRefreshKey = @"com.nova.hossamstateme.discord.refresh";

@interface DiscordSDKBridgeNative ()
@end

@implementation DiscordSDKBridgeNative {
    std::unique_ptr<discordpp::Client> _client;
    std::thread _callbackThread;
    std::mutex _mutex;
    bool _running;
    bool _ready;
    std::string _pendingServer;
    std::string _pendingImage;
    uint64_t _pendingEpoch;
}

+ (instancetype)shared {
    static DiscordSDKBridgeNative *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [DiscordSDKBridgeNative new]; });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _running = false;
        _ready = false;
        _pendingEpoch = 0;
    }
    return self;
}

- (void)dealloc {
    [self stopPump];
}

- (void)initializeSDK {
    std::lock_guard<std::mutex> lock(_mutex);
    if (_client) return;

    _client = std::make_unique<discordpp::Client>();
    _client->SetApplicationId(kApplicationId);
    _client->SetStatusChangedCallback([this](discordpp::Client::Status status,
                                              discordpp::Client::Error,
                                              int32_t) {
        _ready = (status == discordpp::Client::Status::Ready);
        if (_ready && !_pendingServer.empty() && _pendingEpoch > 0) {
            std::string server = _pendingServer;
            std::string image = _pendingImage;
            uint64_t epoch = _pendingEpoch;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self publishPresenceServer:server image:image epoch:epoch];
            });
        }
    });
    _client->SetTokenExpirationCallback([this]() {
        NSString *refresh = [self keychainGet:kRefreshKey];
        if (refresh.length == 0) return;
        std::string refreshToken = refresh.UTF8String;
        _client->RefreshToken(kApplicationId, refreshToken,
            [this](discordpp::ClientResult result,
                   std::string accessToken,
                   std::string refreshToken,
                   discordpp::AuthorizationTokenType tokenType,
                   int32_t,
                   std::string) {
                if (!result.Successful()) return;
                NSString *access = [NSString stringWithUTF8String:accessToken.c_str()];
                NSString *refresh = [NSString stringWithUTF8String:refreshToken.c_str()];
                [self keychainSet:access key:kAccessKey];
                [self keychainSet:refresh key:kRefreshKey];
                _client->UpdateToken(tokenType, accessToken, [this](discordpp::ClientResult updateResult) {
                    if (updateResult.Successful()) _client->Connect();
                });
            });
    });

    [self startPump];
    [self restoreTokenAndConnect];
}

- (void)startPump {
    if (_running) return;
    _running = true;
    _callbackThread = std::thread([this] {
        while (_running) {
            discordpp::RunCallbacks();
            std::this_thread::sleep_for(std::chrono::milliseconds(25));
        }
    });
}

- (void)stopPump {
    if (!_running) return;
    _running = false;
    if (_callbackThread.joinable()) _callbackThread.join();
}

- (void)beginAccountLinking {
    [self initializeSDK];
    auto verifier = _client->CreateAuthorizationCodeVerifier();
    discordpp::AuthorizationArgs args;
    args.SetClientId(kApplicationId);
    args.SetScopes(discordpp::Client::GetDefaultPresenceScopes());
    args.SetCodeChallenge(verifier.Challenge());

    // The verifier is kept only for the lifetime of this authorization attempt.
    std::string codeVerifier = verifier.Verifier();
    _client->Authorize(std::move(args), [this, codeVerifier](discordpp::ClientResult result,
                                                               std::string code,
                                                               std::string redirectUri) {
        if (!result.Successful()) return;
        _client->GetToken(kApplicationId, code, codeVerifier, redirectUri,
            [this](discordpp::ClientResult tokenResult,
                   std::string accessToken,
                   std::string refreshToken,
                   discordpp::AuthorizationTokenType tokenType,
                   int32_t,
                   std::string) {
                if (!tokenResult.Successful()) return;
                NSString *access = [NSString stringWithUTF8String:accessToken.c_str()];
                NSString *refresh = [NSString stringWithUTF8String:refreshToken.c_str()];
                [self keychainSet:access key:kAccessKey];
                [self keychainSet:refresh key:kRefreshKey];
                _client->UpdateToken(tokenType, accessToken, [this](discordpp::ClientResult updateResult) {
                    if (updateResult.Successful()) _client->Connect();
                });
            });
    });
}

- (void)restoreTokenAndConnect {
    NSString *access = [self keychainGet:kAccessKey];
    if (access.length == 0) return;
    _client->UpdateToken(discordpp::AuthorizationTokenType::Bearer,
                         std::string(access.UTF8String),
                         [this](discordpp::ClientResult result) {
        if (result.Successful()) _client->Connect();
    });
}

- (void)publishPresenceServer:(std::string)server image:(std::string)image epoch:(uint64_t)epoch {
    if (!_client || !_ready) return;
    discordpp::Activity activity;
    activity.SetDetails(std::string("Server : ") + server);
    activity.SetState(std::string("by Hossamat"));

    discordpp::ActivityAssets assets;
    if (!image.empty()) assets.SetLargeImage(image);
    assets.SetLargeText(server);
    activity.SetAssets(assets);

    discordpp::ActivityTimestamps timestamps;
    timestamps.SetStart(epoch);
    activity.SetTimestamps(timestamps);
    activity.SetSupportedPlatforms(discordpp::ActivityGamePlatforms::IOS);
    _client->UpdateRichPresence(std::move(activity), [](discordpp::ClientResult) {});
}

- (void)updatePresenceWithServerName:(NSString *)serverName
                            imageURL:(NSString *)imageURL
                          startEpoch:(long long)startEpoch {
    [self initializeSDK];
    _pendingServer = serverName.UTF8String ? serverName.UTF8String : "";
    _pendingImage = imageURL.UTF8String ? imageURL.UTF8String : "";
    _pendingEpoch = (uint64_t)startEpoch;
    if (!_ready) return;
    [self publishPresenceServer:_pendingServer image:_pendingImage epoch:_pendingEpoch];
}

- (void)reconnectWithServerName:(NSString *)serverName
                       imageURL:(NSString *)imageURL
                     startEpoch:(long long)startEpoch {
    [self updatePresenceWithServerName:serverName imageURL:imageURL startEpoch:startEpoch];
}

- (void)clearPresence {
    _pendingServer.clear();
    _pendingImage.clear();
    _pendingEpoch = 0;
    if (!_client) return;
    discordpp::Activity empty;
    _client->UpdateRichPresence(std::move(empty), [](discordpp::ClientResult) {});
}

- (BOOL)isReady {
    return _ready;
}

#pragma mark - Keychain

- (void)keychainSet:(NSString *)value key:(NSString *)key {
    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrAccount: key,
        (__bridge id)kSecValueData: data
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

- (NSString *)keychainGet:(NSString *)key {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrAccount: key,
        (__bridge id)kSecReturnData: @YES,
        (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne
    };
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || !result) return @"";
    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: @"";
}

@end
