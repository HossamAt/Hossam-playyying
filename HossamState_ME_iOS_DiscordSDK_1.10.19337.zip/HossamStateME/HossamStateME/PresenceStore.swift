import Foundation

@MainActor
final class PresenceStore: ObservableObject {
    static let shared = PresenceStore()

    @Published private(set) var active = false
    @Published private(set) var serverName = "Glendale ME"
    @Published private(set) var startEpoch: Int64 = 0
    @Published private(set) var statusText = "غير متصل"

    private let defaults = UserDefaults.standard
    private let activeKey = "presence.active"
    private let serverKey = "presence.server"
    private let epochKey = "presence.startEpoch"

    private init() { restore() }

    func start(server: Server) {
        let sameSession = defaults.bool(forKey: activeKey) && defaults.string(forKey: serverKey) == server.name
        let epoch = sameSession ? defaults.integer(forKey: epochKey) : Int(Date().timeIntervalSince1970)
        active = true
        serverName = server.name
        startEpoch = Int64(epoch)
        statusText = "متصل"
        defaults.set(true, forKey: activeKey)
        defaults.set(server.name, forKey: serverKey)
        defaults.set(epoch, forKey: epochKey)
        DiscordSDKBridge.shared.updatePresence(server: server, startEpoch: Int64(epoch))
    }

    func changeServer(to server: Server) {
        guard active else { return }
        start(server: server)
    }

    func stop() {
        active = false
        statusText = "غير متصل"
        defaults.removeObject(forKey: activeKey)
        defaults.removeObject(forKey: serverKey)
        defaults.removeObject(forKey: epochKey)
        DiscordSDKBridge.shared.clearPresence()
    }

    func reconnect() {
        guard active,
              let server = AppConfig.servers.first(where: { $0.name == serverName }) else { return }
        DiscordSDKBridge.shared.reconnect(server: server, startEpoch: startEpoch)
        statusText = "متصل"
    }

    func elapsedString(now: Date = Date()) -> String {
        guard active, startEpoch > 0 else { return "00:00:00" }
        let seconds = max(0, Int(now.timeIntervalSince1970) - Int(startEpoch))
        return String(format: "%02d:%02d:%02d", seconds / 3600, (seconds / 60) % 60, seconds % 60)
    }

    private func restore() {
        guard defaults.bool(forKey: activeKey) else { return }
        active = true
        serverName = defaults.string(forKey: serverKey) ?? "Glendale ME"
        startEpoch = Int64(defaults.integer(forKey: epochKey))
        statusText = "متصل"
        if let server = AppConfig.servers.first(where: { $0.name == serverName }) {
            DiscordSDKBridge.shared.reconnect(server: server, startEpoch: startEpoch)
        }
    }
}
