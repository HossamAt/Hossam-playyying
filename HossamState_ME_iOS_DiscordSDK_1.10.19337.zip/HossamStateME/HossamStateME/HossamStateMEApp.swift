import SwiftUI

@main
struct HossamStateMEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
