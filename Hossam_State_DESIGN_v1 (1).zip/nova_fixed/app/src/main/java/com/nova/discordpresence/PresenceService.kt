package com.nova.discordpresence

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Owns the complete Rich Presence lifecycle.
 * The Activity only sends configuration to this service.
 */
class PresenceService : Service() {

    data class Config(
        val name: String,
        val details: String,
        val state: String,
        val largeImage: String,
        val largeText: String,
        val smallImage: String,
        val smallText: String,
        val startEpoch: Long
    )

    companion object {
        const val ACTION_UPDATE = "com.nova.discordpresence.UPDATE"
        const val ACTION_STOP = "com.nova.discordpresence.STOP"

        private const val PREFS = "presence_service"
        private const val KEY_ACTIVE = "active"
        private const val APP_ID = 1549333944686612570L
        private const val NOTIFICATION_ID = 77

        @Volatile
        var currentConfig: Config? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var sdkReady = false
    private var stoppedByUser = false
    private val pendingPresenceUpdate = Runnable { currentConfig?.let { sendPresence(it) } }
    private val restorePresenceUpdate = Runnable { currentConfig?.let { sendPresence(it) } }

    /** Run the SDK callback pump on Android's main looper. */
    private val callbackPump = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            try {
                NativeBridge.runCallbacks()
            } catch (_: Throwable) {
                // Never let an SDK callback-pump problem kill the foreground service.
            }
            handler.postDelayed(this, 50L)
        }
    }

    /**
     * Re-send the current activity occasionally so the presence can recover if
     * the Discord app was restarted or its RPC connection was temporarily lost.
     */
    private val retryPresence = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            val config = currentConfig
            if (config != null) {
                sendPresence(config)
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        restoreConfig()

        // MainActivity calls DiscordSocialSdkInit.setEngineActivity() before
        // starting this service. Keep all SDK Client operations in this service.
        sdkReady = try {
            NativeBridge.init(this, APP_ID)
        } catch (_: Throwable) {
            false
        }

        handler.post(callbackPump)

        // If Android recreated the service while a presence was active, restore
        // it once the service is fully started. Do not send duplicate requests
        // from both onCreate() and onStartCommand().
        if (sdkReady && currentConfig != null) {
            handler.postDelayed(restorePresenceUpdate, 700L)
        }

        handler.postDelayed(retryPresence, 60_000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopPresenceByUser()
            ACTION_UPDATE -> {
                stoppedByUser = false

                val config = Config(
                    intent.getStringExtra("name") ?: "OneState",
                    intent.getStringExtra("details") ?: "Server : Fortuna ME",
                    intent.getStringExtra("state") ?: "by Hossamat",
                    intent.getStringExtra("largeImage") ?: "",
                    intent.getStringExtra("largeText") ?: "",
                    intent.getStringExtra("smallImage") ?: "",
                    intent.getStringExtra("smallText") ?: "",
                    intent.getLongExtra("startEpoch", System.currentTimeMillis() / 1000L)
                )

                currentConfig = config
                saveConfig(config)

                if (!sdkReady) {
                    sdkReady = try {
                        NativeBridge.init(this, APP_ID)
                    } catch (_: Throwable) {
                        false
                    }
                }

                // A fresh user selection supersedes any restore request from
                // service recreation. Coalesce rapid server changes into one
                // asynchronous SDK request.
                handler.removeCallbacks(restorePresenceUpdate)
                handler.removeCallbacks(pendingPresenceUpdate)
                handler.postDelayed(pendingPresenceUpdate, 250L)
            }
        }

        // START_STICKY lets Android recreate the service after a resource kill.
        return START_STICKY
    }

    private fun sendPresence(config: Config) {
        if (stoppedByUser) return

        if (!sdkReady) {
            sdkReady = try {
                NativeBridge.init(this, APP_ID)
            } catch (_: Throwable) {
                false
            }
        }
        if (!sdkReady) return

        try {
            NativeBridge.startPresence(
                config.name,
                config.details,
                config.state,
                config.largeImage,
                config.largeText,
                config.smallImage,
                config.smallText,
                config.startEpoch
            )
        } catch (_: Throwable) {
            // Keep the foreground service alive; the retry loop can recover.
        }
    }

    private fun stopPresenceByUser() {
        stoppedByUser = true
        clearSavedConfig()
        currentConfig = null
        handler.removeCallbacksAndMessages(null)

        try {
            if (sdkReady) NativeBridge.stopPresence()
            // Intentionally keep the native Client alive until the process dies.
            // Destroying it while an asynchronous RPC callback is pending is
            // unnecessary and can make a later reconnect less reliable.
        } catch (_: Throwable) {
            // Explicit stop should never crash the app.
        }

        sdkReady = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "presence",
            "Hossam State",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return Notification.Builder(this, "presence")
            .setContentTitle("Hossam State")
            .setContentText("OneState • Rich Presence يعمل بالخلفية")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun saveConfig(c: Config) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, true)
            .putString("name", c.name)
            .putString("details", c.details)
            .putString("state", c.state)
            .putString("largeImage", c.largeImage)
            .putString("largeText", c.largeText)
            .putString("smallImage", c.smallImage)
            .putString("smallText", c.smallText)
            .putLong("startEpoch", c.startEpoch)
            .apply()
    }

    private fun restoreConfig() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!p.getBoolean(KEY_ACTIVE, false)) return

        currentConfig = Config(
            p.getString("name", "OneState") ?: "OneState",
            p.getString("details", "Server : Fortuna ME") ?: "Server : Fortuna ME",
            p.getString("state", "by Hossamat") ?: "by Hossamat",
            p.getString("largeImage", "") ?: "",
            p.getString("largeText", "") ?: "",
            p.getString("smallImage", "") ?: "",
            p.getString("smallText", "") ?: "",
            p.getLong("startEpoch", System.currentTimeMillis() / 1000L)
        )
    }

    private fun clearSavedConfig() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Removing the app task must not be treated as an explicit disconnect.
        // Keep the started foreground service alive and ask Android to recreate it
        // if the process is reclaimed.
        if (!stoppedByUser) {
            try {
                val restartIntent = Intent(this, PresenceService::class.java).apply {
                    action = ACTION_UPDATE
                    currentConfig?.let { c ->
                        putExtra("name", c.name)
                        putExtra("details", c.details)
                        putExtra("state", c.state)
                        putExtra("largeImage", c.largeImage)
                        putExtra("largeText", c.largeText)
                        putExtra("smallImage", c.smallImage)
                        putExtra("smallText", c.smallText)
                        putExtra("startEpoch", c.startEpoch)
                    }
                }
                if (currentConfig != null) {
                    androidx.core.content.ContextCompat.startForegroundService(this, restartIntent)
                }
            } catch (_: Throwable) {
                // Android/OEM may reject a restart request; START_STICKY remains active.
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        // Do not clear the native client here. Android can destroy/recreate a
        // started service and START_STICKY should be able to recover cleanly.
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

}
