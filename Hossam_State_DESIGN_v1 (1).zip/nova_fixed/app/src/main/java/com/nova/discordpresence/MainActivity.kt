package com.nova.discordpresence

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.Manifest
import android.content.pm.PackageManager
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import coil.load

class MainActivity : AppCompatActivity() {

    companion object {
        var lastStatus: String = "جاهز"
        private const val APP_ID = 1549333944686612570L
        private const val DISCORD_URL = "https://discord.gg/DK4ZRHB4g"
            }

    data class Server(val name: String, val imageUrl: String)

    private val servers = listOf(
        Server("Alameda ME", "https://cdn.discordapp.com/emojis/1346557146409472070.png"),
        Server("Barry ME", "https://cdn.discordapp.com/emojis/1412049991991820358.png"),
        Server("Bell ME", "https://cdn.discordapp.com/emojis/1341057206140801085.png"),
        Server("Chico ME", "https://cdn.discordapp.com/emojis/1341057490258886721.png"),
        Server("Covina ME", "https://cdn.discordapp.com/emojis/1341057310981619784.png"),
        Server("Forest ME", "https://cdn.discordapp.com/emojis/1389265233553522778.png"),
        Server("Fortuna ME", "https://cdn.discordapp.com/emojis/1364572804250472448.png"),
        Server("Glendale ME", "https://f.top4top.io/p_3910rgmcv0.png"),
        Server("Hemet ME", "https://cdn.discordapp.com/emojis/1412049963973738596.png"),
        Server("Hills ME", "https://cdn.discordapp.com/emojis/1341057349087002735.png"),
        Server("Homeland ME", "https://cdn.discordapp.com/emojis/1343966484333989970.png"),
        Server("Laguna ME", "https://cdn.discordapp.com/emojis/1341057622941634671.png"),
        Server("Lincoln ME", "https://cdn.discordapp.com/emojis/1356278039570415867.png"),
        Server("Lomita ME", "https://cdn.discordapp.com/emojis/1341057167804858369.png"),
        Server("Lynwood ME", "https://cdn.discordapp.com/emojis/1341057244707422308.png"),
        Server("Madera ME", "https://cdn.discordapp.com/emojis/1350846504079855647.png"),
        Server("Malibu ME", "https://cdn.discordapp.com/emojis/1487960389982486648.png"),
        Server("Mesa ME", "https://cdn.discordapp.com/emojis/1341057580209799260.png"),
        Server("Napa ME", "https://cdn.discordapp.com/emojis/1341057528842289235.png"),
        Server("Orange ME", "https://b.top4top.io/p_3910rj4y80.png"),
        Server("Redland ME", "https://d.top4top.io/p_39104dukk0.png"),
        Server("Solano ME", "https://k.top4top.io/p_39104u11a0.png"),
        Server("Wasco ME", "https://e.top4top.io/p_3910qazz50.png"),
        Server("Yuba ME", "https://g.top4top.io/p_3910scuj90.png")
    )

    private lateinit var selectedServer: Server
    private lateinit var selectedImage: ImageView
    private lateinit var selectedName: TextView
    private lateinit var connection: TextView
    private lateinit var timerText: TextView
    private lateinit var serverList: LinearLayout
    private lateinit var startButton: Button
    private lateinit var reconnectButton: Button
    private var initialized = false
    private val timerHandler = Handler(Looper.getMainLooper())
    private val timerRunnable = object : Runnable {
        override fun run() {
            updateTimer()
            timerHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.discord.socialsdk.DiscordSocialSdkInit.setEngineActivity(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        selectedServer = servers.first { it.name == "Glendale ME" }
        buildUi()
        syncRunningPresence()
        refreshSelectedCard()
        timerHandler.post(timerRunnable)
    }

    private fun syncRunningPresence() {
        val active = PresenceService.currentConfig ?: return
        val activeName = active.details.removePrefix("Server : ")
        servers.firstOrNull { it.name == activeName }?.let { selectedServer = it }
        initialized = true
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = Color.WHITE): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        includeFontPadding = false
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(3, 9, 17)) }

        val background = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.62f
            load(R.drawable.hossam_state_background) { crossfade(true) }
        }
        root.addView(background, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this).apply { setBackgroundColor(Color.argb(145, 2, 8, 16)) }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(16), dp(20), dp(16), dp(24))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val title = text("Hossam State", 27f).apply {
            typeface = Typeface.create("sans", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(title, LinearLayout.LayoutParams(-1, dp(38)))

        val credit = text("تطوير Hossamat", 12f, Color.rgb(182, 197, 214)).apply { gravity = Gravity.CENTER }
        content.addView(credit, LinearLayout.LayoutParams(-1, dp(22)))

        addSpace(content, 10)
        val discord = Button(this).apply {
            text = "◈  مجتمع الديسكورد"
            isAllCaps = false
            textSize = 12f
            setTextColor(Color.rgb(205, 219, 234))
            background = getDrawable(R.drawable.bg_button)
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL))) }
        }
        val discordParams = LinearLayout.LayoutParams(dp(180), dp(42)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        content.addView(discord, discordParams)

        addSpace(content, 18)
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(17), dp(15), dp(17), dp(15))
            setBackgroundResource(R.drawable.bg_card)
        }
        val statusRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 15f
            setTextColor(Color.rgb(49, 209, 124))
        }
        statusRow.addView(statusDot, LinearLayout.LayoutParams(dp(24), dp(28)))
        connection = text("غير متصل", 14f, Color.rgb(194, 207, 222))
        statusRow.addView(connection, LinearLayout.LayoutParams(0, dp(28), 1f))
        val timerLabel = text("المدة", 11f, Color.rgb(133, 157, 181))
        statusRow.addView(timerLabel, LinearLayout.LayoutParams(dp(48), dp(28)))
        timerText = text("00:00:00", 15f, Color.WHITE).apply { gravity = Gravity.CENTER }
        statusRow.addView(timerText, LinearLayout.LayoutParams(dp(84), dp(28)))
        statusCard.addView(statusRow)

        addSpace(statusCard, 9)
        val current = text("السيرفر: —", 12f, Color.rgb(157, 181, 207)).apply { gravity = Gravity.CENTER_VERTICAL }
        selectedName = current
        statusCard.addView(current, LinearLayout.LayoutParams(-1, dp(25)))
        content.addView(statusCard)

        addSpace(content, 10)
        startButton = Button(this).apply {
            text = "اتصال"
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_primary_button)
            setOnClickListener { togglePresence() }
        }
        content.addView(startButton, LinearLayout.LayoutParams(-1, dp(48)))

        addSpace(content, 8)
        reconnectButton = Button(this).apply {
            text = "↻  إعادة الاتصال"
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.rgb(206, 220, 235))
            background = getDrawable(R.drawable.bg_button)
            setOnClickListener { startSelectedPresence() }
        }
        content.addView(reconnectButton, LinearLayout.LayoutParams(-1, dp(46)))

        addSpace(content, 22)
        val choose = text("السيرفرات", 17f, Color.WHITE).apply {
            typeface = Typeface.create("sans", Typeface.BOLD)
            gravity = Gravity.RIGHT
        }
        content.addView(choose, LinearLayout.LayoutParams(-1, dp(28)))
        addSpace(content, 8)

        serverList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        content.addView(serverList)
        buildServerList()

        addSpace(content, 18)
        val footer = text("Hossam State  •  OneState Rich Presence", 11f, Color.rgb(126, 151, 177)).apply { gravity = Gravity.CENTER }
        content.addView(footer, LinearLayout.LayoutParams(-1, dp(24)))

        setContentView(root)
    }

    private fun buildServerList() {
        serverList.removeAllViews()
        servers.forEach { server ->
            val card = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(12), dp(7), dp(12), dp(7))
                setBackgroundResource(if (server.name == selectedServer.name) R.drawable.bg_card_selected else R.drawable.bg_card)
                setOnClickListener {
                    if (server.name != selectedServer.name) {
                        selectedServer = server
                        refreshSelectedCard()
                        if (initialized) updateRunningPresence()
                    }
                }
            }
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                load(server.imageUrl) { crossfade(true) }
            }
            card.addView(image, LinearLayout.LayoutParams(dp(44), dp(44)))
            val name = text(server.name, 14f, Color.WHITE).apply { gravity = Gravity.CENTER_VERTICAL }
            name.setPadding(dp(12), 0, dp(4), 0)
            card.addView(name, LinearLayout.LayoutParams(0, -1, 1f))
            val tag = text("OneState", 10f, Color.rgb(123, 151, 180)).apply { gravity = Gravity.CENTER }
            card.addView(tag, LinearLayout.LayoutParams(dp(62), -1))
            val params = LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(6) }
            serverList.addView(card, params)
        }
    }

    private fun refreshSelectedCard() {
        selectedName.text = "السيرفر: ${selectedServer.name}"
        connection.text = if (initialized) "متصل" else "غير متصل"
        connection.setTextColor(if (initialized) Color.rgb(72, 220, 137) else Color.rgb(194, 207, 222))
        startButton.text = if (initialized) "إيقاف الاتصال" else "اتصال"
        reconnectButton.isEnabled = true
        buildServerList()
    }

    private fun updateTimer() {
        val epoch = PresenceService.currentConfig?.startEpoch
        if (!initialized || epoch == null) {
            timerText.text = "00:00:00"
            return
        }
        val seconds = ((System.currentTimeMillis() / 1000L) - epoch).coerceAtLeast(0L)
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        timerText.text = String.format("%02d:%02d:%02d", h, m, s)
    }

    private fun togglePresence() {
        if (initialized) stopRunningPresence() else startSelectedPresence()
    }

    private fun startSelectedPresence() {
        try {
            connection.text = "جارٍ الاتصال…"
            connection.setTextColor(Color.rgb(255, 208, 92))
            startButton.isEnabled = false
            val now = System.currentTimeMillis() / 1000L
            val config = PresenceService.Config("OneState", "Server : ${selectedServer.name}", "by Hossamat", selectedServer.imageUrl, selectedServer.name, "", "", now)
            PresenceService.currentConfig = config
            startServiceWithConfig()
            initialized = true
            connection.text = "متصل"
            connection.setTextColor(Color.rgb(72, 220, 137))
            startButton.text = "إيقاف الاتصال"
            buildServerList()
        } catch (e: Exception) {
            initialized = false
            connection.text = "فشل الاتصال"
            connection.setTextColor(Color.rgb(255, 120, 120))
        } finally {
            startButton.isEnabled = true
        }
    }

    private fun updateRunningPresence() {
        val old = PresenceService.currentConfig
        val startEpoch = old?.startEpoch ?: (System.currentTimeMillis() / 1000L)
        val config = PresenceService.Config("OneState", "Server : ${selectedServer.name}", "by Hossamat", selectedServer.imageUrl, selectedServer.name, "", "", startEpoch)
        PresenceService.currentConfig = config
        startServiceWithConfig()
        connection.text = "متصل"
        connection.setTextColor(Color.rgb(72, 220, 137))
        buildServerList()
    }

    private fun stopRunningPresence() {
        initialized = false
        PresenceService.currentConfig = null
        stopService(Intent(this, PresenceService::class.java).apply { action = PresenceService.ACTION_STOP })
        refreshSelectedCard()
    }

    private fun startServiceWithConfig() {
        val c = PresenceService.currentConfig ?: return
        val intent = Intent(this, PresenceService::class.java).apply {
            action = PresenceService.ACTION_UPDATE
            putExtra("name", c.name)
            putExtra("details", c.details)
            putExtra("state", c.state)
            putExtra("largeImage", c.largeImage)
            putExtra("largeText", c.largeText)
            putExtra("smallImage", c.smallImage)
            putExtra("smallText", c.smallText)
            putExtra("startEpoch", c.startEpoch)
        }
        androidx.core.content.ContextCompat.startForegroundService(this, intent)
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    override fun onBackPressed() {
        if (initialized) moveTaskToBack(true) else super.onBackPressed()
    }

    override fun onDestroy() {
        timerHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
