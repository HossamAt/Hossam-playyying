package com.nova.discordpresence

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class PresenceService : Service() {

    data class Config(
        val name: String,
        val details: String,
        val state: String,
        val largeImage: String,
        val largeText: String,
        val smallImage: String,
        val smallText: String,
        val startEpoch: Long
    )

    companion object {
        const val ACTION_UPDATE = "com.nova.discordpresence.UPDATE"
        const val ACTION_STOP = "com.nova.discordpresence.STOP"
        private const val PREFS = "presence_service"
        private const val KEY_ACTIVE = "active"

        @Volatile
        var currentConfig: Config? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var sdkReady = false

    private val refresh = object : Runnable {
        override fun run() {
            currentConfig?.let { c ->
                NativeBridge.startPresence(
                    c.name, c.details, c.state,
                    c.largeImage, c.largeText,
                    c.smallImage, c.smallText,
                    c.startEpoch
                )
            }
            handler.postDelayed(this, 20_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()

        val channel = NotificationChannel(
            "presence",
            "Hossam playing",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = Notification.Builder(this, "presence")
            .setContentTitle("Hossam playing")
            .setContentText("OneState • Rich Presence يعمل بالخلفية")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        // Must happen immediately when the foreground service starts.
        startForeground(77, notification)

        // Native SDK lifecycle is owned by this long-lived service.
        sdkReady = NativeBridge.init(this, 1549333944686612570L)

        restoreConfig()
        handler.post(refresh)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                clearSavedConfig()
                currentConfig = null
                handler.removeCallbacks(refresh)
                if (sdkReady) NativeBridge.stopPresence()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_UPDATE -> {
                currentConfig = Config(
                    intent.getStringExtra("name") ?: "OneState",
                    intent.getStringExtra("details") ?: "Server : Fortuna ME",
                    intent.getStringExtra("state") ?: "by Hossamat",
                    intent.getStringExtra("largeImage") ?: "",
                    intent.getStringExtra("largeText") ?: "",
                    intent.getStringExtra("smallImage") ?: "",
                    intent.getStringExtra("smallText") ?: "",
                    intent.getLongExtra("startEpoch", System.currentTimeMillis() / 1000L)
                )
                saveConfig(currentConfig!!)
                if (!sdkReady) sdkReady = NativeBridge.init(this, 1549333944686612570L)

                // Update immediately without stopping/restarting the service.
                currentConfig?.let { c ->
                    NativeBridge.startPresence(
                        c.name, c.details, c.state,
                        c.largeImage, c.largeText,
                        c.smallImage, c.smallText,
                        c.startEpoch
                    )
                }
            }
        }
        return START_STICKY
    }

    private fun saveConfig(c: Config) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, true)
            .putString("name", c.name)
            .putString("details", c.details)
            .putString("state", c.state)
            .putString("largeImage", c.largeImage)
            .putString("largeText", c.largeText)
            .putString("smallImage", c.smallImage)
            .putString("smallText", c.smallText)
            .putLong("startEpoch", c.startEpoch)
            .apply()
    }

    private fun restoreConfig() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!p.getBoolean(KEY_ACTIVE, false)) return
        currentConfig = Config(
            p.getString("name", "OneState") ?: "OneState",
            p.getString("details", "Server : Fortuna ME") ?: "Server : Fortuna ME",
            p.getString("state", "by Hossamat") ?: "by Hossamat",
            p.getString("largeImage", "") ?: "",
            p.getString("largeText", "") ?: "",
            p.getString("smallImage", "") ?: "",
            p.getString("smallText", "") ?: "",
            p.getLong("startEpoch", System.currentTimeMillis() / 1000L)
        )
    }

    private fun clearSavedConfig() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        // Do NOT call NativeBridge.shutdown() here. Android may recreate the
        // service, and the native client must not be torn down just because
        // the service instance is being recreated.
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
