package com.nova.discordpresence

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import coil.load
import com.discord.socialsdk.DiscordSocialSdkInit

class MainActivity : AppCompatActivity() {

    companion object {
        var lastStatus: String = "جاهز"
        private const val APP_ID = 1549333944686612570L
        private const val DISCORD_URL = "https://discord.gg/DK4ZRHB4g"
    }

    data class Server(val name: String, val imageUrl: String)

    private val servers = listOf(
        Server("Alameda ME", "https://cdn.discordapp.com/emojis/1346557146409472070.png"),
        Server("Barry ME", "https://cdn.discordapp.com/emojis/1412049991991820358.png"),
        Server("Bell ME", "https://cdn.discordapp.com/emojis/1341057206140801085.png"),
        Server("Chico ME", "https://cdn.discordapp.com/emojis/1341057490258886721.png"),
        Server("Covina ME", "https://cdn.discordapp.com/emojis/1341057310981619784.png"),
        Server("Forest ME", "https://cdn.discordapp.com/emojis/1389265233553522778.png"),
        Server("Fortuna ME", "https://cdn.discordapp.com/emojis/1364572804250472448.png"),
        Server("Glendale ME", "https://f.top4top.io/p_3910rgmcv0.png"),
        Server("Hemet ME", "https://cdn.discordapp.com/emojis/1412049963973738596.png"),
        Server("Hills ME", "https://cdn.discordapp.com/emojis/1341057349087002735.png"),
        Server("Homeland ME", "https://cdn.discordapp.com/emojis/1343966484333989970.png"),
        Server("Laguna ME", "https://cdn.discordapp.com/emojis/1341057622941634671.png"),
        Server("Lincoln ME", "https://cdn.discordapp.com/emojis/1356278039570415867.png"),
        Server("Lomita ME", "https://cdn.discordapp.com/emojis/1341057167804858369.png"),
        Server("Lynwood ME", "https://cdn.discordapp.com/emojis/1341057244707422308.png"),
        Server("Madera ME", "https://cdn.discordapp.com/emojis/1350846504079855647.png"),
        Server("Malibu ME", "https://cdn.discordapp.com/emojis/1487960389982486648.png"),
        Server("Mesa ME", "https://cdn.discordapp.com/emojis/1341057580209799260.png"),
        Server("Napa ME", "https://cdn.discordapp.com/emojis/1341057528842289235.png"),
        Server("Orange ME", "https://b.top4top.io/p_3910rj4y80.png"),
        Server("Redland ME", "https://d.top4top.io/p_39104dukk0.png"),
        Server("Solano ME", "https://k.top4top.io/p_39104u11a0.png"),
        Server("Wasco ME", "https://e.top4top.io/p_3910qazz50.png"),
        Server("Yuba ME", "https://g.top4top.io/p_3910scuj90.png")
    )

    private lateinit var selectedServer: Server
    private lateinit var selectedImage: ImageView
    private lateinit var selectedName: TextView
    private lateinit var connection: TextView
    private lateinit var timerHint: TextView
    private lateinit var serverList: LinearLayout
    private lateinit var startButton: Button
    private var initialized = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiscordSocialSdkInit.setEngineActivity(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        selectedServer = servers.first { it.name == "Glendale ME" }
        buildUi()
        refreshSelectedCard()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = Color.WHITE): TextView = TextView(this).apply {
        this.text = value
        textSize = size
        setTextColor(color)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(com.nova.discordpresence.R.drawable.app_background)
            setPadding(dp(18), dp(16), dp(18), dp(14))
        }

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(210), 0, dp(12))
        }
        scroll.addView(content)

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundResource(R.drawable.bg_card)
        }
        val logo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            load("https://a.top4top.io/p_3910fuin80.png")
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)))
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        titleBox.addView(text("Hossam playing", 21f))
        titleBox.addView(text("Discord Rich Presence", 13f, Color.rgb(174, 201, 229)))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header)

        addSpace(content, 12)
        val sectionTitle = text("السيرفر الحالي", 16f)
        sectionTitle.setTypeface(null, android.graphics.Typeface.BOLD)
        content.addView(sectionTitle)
        addSpace(content, 8)

        val selectedCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundResource(R.drawable.bg_card_selected)
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        selectedImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        row.addView(selectedImage, LinearLayout.LayoutParams(dp(64), dp(64)))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        selectedName = text("", 18f)
        info.addView(selectedName)
        info.addView(text("OneState", 13f, Color.rgb(183, 205, 230)))
        info.addView(text("by Hossamat", 13f, Color.rgb(72, 163, 255)))
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        selectedCard.addView(row)
        addSpace(selectedCard, 10)
        connection = text("●  جاهز للتشغيل", 13f, Color.rgb(175, 196, 218))
        selectedCard.addView(connection)
        timerHint = text("التايمر يبدأ عند التشغيل", 12f, Color.rgb(143, 169, 195))
        selectedCard.addView(timerHint)
        addSpace(selectedCard, 12)

        startButton = Button(this).apply {
            text = "▶  تشغيل Rich Presence"
            setTextColor(Color.WHITE)
            textSize = 14f
            background = getDrawable(R.drawable.bg_primary_button)
            isAllCaps = false
            setPadding(0, dp(4), 0, dp(4))
            setOnClickListener { togglePresence() }
        }
        selectedCard.addView(startButton, LinearLayout.LayoutParams(-1, dp(52)))
        content.addView(selectedCard)

        addSpace(content, 16)
        val choose = text("اختر السيرفر", 17f)
        choose.setTypeface(null, android.graphics.Typeface.BOLD)
        content.addView(choose)
        addSpace(content, 8)

        serverList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(serverList)
        buildServerList()

        addSpace(content, 12)
        val reconnect = Button(this).apply {
            text = "↻  إعادة الاتصال"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_button)
            setOnClickListener { startSelectedPresence() }
        }
        content.addView(reconnect, LinearLayout.LayoutParams(-1, dp(50)))

        addSpace(content, 8)
        val discord = Button(this).apply {
            text = "◉  Discord Community"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_button)
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL)))
            }
        }
        content.addView(discord, LinearLayout.LayoutParams(-1, dp(50)))

        addSpace(content, 18)
        val credit = text("تم تطويره من قبل\nHossam at", 13f, Color.rgb(169, 197, 226)).apply {
            gravity = Gravity.CENTER
        }
        content.addView(credit, LinearLayout.LayoutParams(-1, -2))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun buildServerList() {
        serverList.removeAllViews()
        servers.forEach { server ->
            val card = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(9), dp(12), dp(9))
                setBackgroundResource(if (server.name == selectedServer.name) R.drawable.bg_card_selected else R.drawable.bg_card)
                setOnClickListener {
                    if (server.name != selectedServer.name) {
                        selectedServer = server
                        refreshSelectedCard()
                        if (initialized) {
                            updateRunningPresence()
                        }
                    }
                }
            }
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                load(server.imageUrl) { crossfade(true) }
            }
            card.addView(image, LinearLayout.LayoutParams(dp(46), dp(46)))
            val name = text(server.name, 15f)
            name.setPadding(dp(12), 0, 0, 0)
            card.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val tag = text("OneState", 11f, Color.rgb(134, 165, 196))
            card.addView(tag)
            val params = LinearLayout.LayoutParams(-1, dp(66))
            params.bottomMargin = dp(7)
            serverList.addView(card, params)
        }
    }

    private fun refreshSelectedCard() {
        selectedName.text = selectedServer.name
        selectedImage.load(selectedServer.imageUrl) { crossfade(true) }
        connection.text = if (initialized) "●  Rich Presence يعمل" else "●  جاهز للتشغيل"
        connection.setTextColor(if (initialized) Color.rgb(49, 209, 124) else Color.rgb(175, 196, 218))
        startButton.text = if (initialized) "⏹  إيقاف Rich Presence" else "▶  تشغيل Rich Presence"
        buildServerListIfReady()
    }

    private fun buildServerListIfReady() {
        if (::serverList.isInitialized && serverList.childCount > 0) buildServerList()
    }


private fun togglePresence() {
    if (initialized) {
        stopRunningPresence()
    } else {
        startSelectedPresence()
    }
}

private fun startSelectedPresence() {
    try {
        connection.text = "●  جاري تشغيل Rich Presence..."
        connection.setTextColor(Color.rgb(255, 210, 80))
        startButton.isEnabled = false

        val now = System.currentTimeMillis() / 1000L
        val config = PresenceService.Config(
            "OneState",
            "Server : ${selectedServer.name}",
            "by Hossamat",
            selectedServer.imageUrl,
            selectedServer.name,
            "",
            "",
            now
        )

        // The foreground service owns the Discord SDK lifecycle.
        // The Activity only sends the selected server/config to it.
        PresenceService.currentConfig = config
        startServiceWithConfig()

        initialized = true
        connection.text = "●  Discord Connected"
        connection.setTextColor(Color.rgb(49, 209, 124))
        timerHint.text = "Timer يعمل من لحظة التشغيل"
        startButton.text = "⏹  إيقاف Rich Presence"
        buildServerList()
    } catch (e: Exception) {
        initialized = false
        connection.text = "●  تعذر التشغيل: ${e.message ?: "Unknown error"}"
        connection.setTextColor(Color.rgb(255, 120, 120))
        timerHint.text = "تأكد أن Discord مفتوح ومسجل الدخول"
    } finally {
        startButton.isEnabled = true
    }
}

private fun updateRunningPresence() {
    val old = PresenceService.currentConfig
    val startEpoch = old?.startEpoch ?: (System.currentTimeMillis() / 1000L)

    val config = PresenceService.Config(
        "OneState",
        "Server : ${selectedServer.name}",
        "by Hossamat",
        selectedServer.imageUrl,
        selectedServer.name,
        "",
        "",
        startEpoch
    )
    PresenceService.currentConfig = config
    startServiceWithConfig()

    connection.text = "●  Discord Connected"
    connection.setTextColor(Color.rgb(49, 209, 124))
    timerHint.text = "Timer مستمر بدون إعادة تشغيل"
}

private fun stopRunningPresence() {
    initialized = false
    PresenceService.currentConfig = null
    val intent = Intent(this, PresenceService::class.java).apply {
        action = PresenceService.ACTION_STOP
    }
    stopService(intent)
    connection.text = "●  متوقف"
    connection.setTextColor(Color.LTGRAY)
    timerHint.text = "التايمر متوقف"
    startButton.text = "▶  تشغيل Rich Presence"
    buildServerList()
}

private fun startServiceWithConfig() {
    val c = PresenceService.currentConfig ?: return
    val intent = Intent(this, PresenceService::class.java).apply {
        action = PresenceService.ACTION_UPDATE
        putExtra("name", c.name)
        putExtra("details", c.details)
        putExtra("state", c.state)
        putExtra("largeImage", c.largeImage)
        putExtra("largeText", c.largeText)
        putExtra("smallImage", c.smallImage)
        putExtra("smallText", c.smallText)
        putExtra("startEpoch", c.startEpoch)
    }
    androidx.core.content.ContextCompat.startForegroundService(this, intent)
}

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addSpace(parent: View, height: Int) {
        if (parent is LinearLayout) parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
