# Hossam playing

Android Discord Rich Presence app using the official Discord Social SDK.

## User flow
- Choose a server.
- Press Run.
- The app automatically uses the fixed OneState / Server / by Hossamat presence values.
- Users cannot edit server or Rich Presence data.

## Build
The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, compile/target SDK 35, and arm64-v8a.

The GitHub Actions workflow can also extract a project ZIP uploaded to the repository and build the Gradle project.
