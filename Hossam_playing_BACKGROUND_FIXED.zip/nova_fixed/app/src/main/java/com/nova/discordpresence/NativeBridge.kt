package com.nova.discordpresence

object NativeBridge {
    init { System.loadLibrary("nova_presence") }

    external fun init(activity: android.app.Activity, applicationId: Long): Boolean

    external fun startPresence(
        name: String,
        details: String,
        state: String,
        largeImage: String,
        largeText: String,
        smallImage: String,
        smallText: String,
        startEpoch: Long
    ): Boolean

    external fun stopPresence()
    external fun shutdown()

    @JvmStatic
    fun onNativeEvent(type: String, message: String) {
        MainActivity.lastStatus = "$type: $message"
    }
}
