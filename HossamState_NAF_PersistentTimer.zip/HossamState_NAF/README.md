Hossam State NAF — نسخة شمال افريقيا

# Hossam playing

Android Discord Rich Presence app using the official Discord Social SDK.

## User flow
- Choose a server.
- Press Run.
- The app automatically uses the fixed OneState / Server / by Hossamat presence values.
- Users cannot edit server or Rich Presence data.

## Build
The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17, compile/target SDK 35, and arm64-v8a.

The GitHub Actions workflow can also extract a project ZIP uploaded to the repository and build the Gradle project.


## Background / stability notes
- Rich Presence is implemented with Discord Social SDK 1.10+ unauthenticated Android RPC.
- The foreground service owns the native Discord client and keeps the Activity out of the SDK update path.
- Server changes are sent to the same service/client; the elapsed timestamp is preserved.
- The app moves the Activity to the background instead of finishing it while Rich Presence is active because the Android SDK's RPC transport is initialized from the engine Activity.
- The app requests Android battery-optimization exemption when Rich Presence is first enabled, where the device allows it.


## Persistent Rich Presence timer
The NAF build persists the Rich Presence start timestamp in the foreground service's SharedPreferences.
Reconnecting after a Discord/RPC disconnect, restarting the service, or restarting the app reuses the
same timestamp for the same selected server, so the elapsed timer continues instead of resetting.
Selecting a different server starts a new timestamp. Pressing the app's stop button clears the saved
session intentionally.
