#include <jni.h>
#include <android/log.h>
#include <memory>
#include <mutex>
#include <ctime>
#include <string>
#include <atomic>
#include "discordpp.h"

#define TAG "NovaPresence"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::shared_ptr<discordpp::Client> g_client;
static std::mutex g_mutex;
static uint64_t g_appId = 1549333944686612570ULL;
static JavaVM* g_vm = nullptr;

static JNIEnv* getEnv(bool* attached) {
    if (attached) *attached = false;
    if (!g_vm) return nullptr;

    JNIEnv* env = nullptr;
    const jint result = g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (result == JNI_OK) return env;
    if (result != JNI_EDETACHED) return nullptr;

    if (g_vm->AttachCurrentThread(reinterpret_cast<void**>(&env), nullptr) != JNI_OK) return nullptr;
    if (attached) *attached = true;
    return env;
}

static void notifyJava(const char* type, const std::string& message) {
    bool attached = false;
    JNIEnv* env = getEnv(&attached);
    if (!env) return;

    jclass cls = env->FindClass("com/nova/discordpresence/NativeBridge");
    if (!cls) {
        if (attached) g_vm->DetachCurrentThread();
        return;
    }

    jmethodID mid = env->GetStaticMethodID(
        cls,
        "onNativeEvent",
        "(Ljava/lang/String;Ljava/lang/String;)V"
    );

    if (!mid) {
        env->DeleteLocalRef(cls);
        if (attached) g_vm->DetachCurrentThread();
        return;
    }

    jstring jt = env->NewStringUTF(type ? type : "UNKNOWN");
    jstring jm = env->NewStringUTF(message.c_str());
    if (jt && jm) {
        env->CallStaticVoidMethod(cls, mid, jt, jm);
    }

    if (jt) env->DeleteLocalRef(jt);
    if (jm) env->DeleteLocalRef(jm);
    env->DeleteLocalRef(cls);

    if (attached) g_vm->DetachCurrentThread();
}

extern "C" jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_nova_discordpresence_NativeBridge_init(
    JNIEnv*, jobject, jobject, jlong appId) {

    std::lock_guard<std::mutex> lock(g_mutex);
    g_appId = static_cast<uint64_t>(appId);

    try {
        if (!g_client) {
            // Android direct Rich Presence (SDK 1.10+) does not require
            // Client::Connect or OAuth authentication.
            g_client = std::make_shared<discordpp::Client>();

            g_client->AddLogCallback(
                [](auto msg, auto severity) {
                    LOGI("%s", msg.c_str());
                },
                discordpp::LoggingSeverity::Info
            );
        }

        g_client->SetApplicationId(g_appId);
        return JNI_TRUE;
    } catch (const std::exception& e) {
        LOGE("Native init exception: %s", e.what());
        g_client.reset();
        return JNI_FALSE;
    } catch (...) {
        LOGE("Native init unknown exception");
        g_client.reset();
        return JNI_FALSE;
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_nova_discordpresence_NativeBridge_runCallbacks(JNIEnv*, jobject) {
    try {
        discordpp::RunCallbacks();
    } catch (const std::exception& e) {
        LOGE("RunCallbacks exception: %s", e.what());
    } catch (...) {
        LOGE("RunCallbacks unknown exception");
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_nova_discordpresence_NativeBridge_startPresence(
    JNIEnv* env,
    jobject,
    jstring jname,
    jstring jdetails,
    jstring jstate,
    jstring jlargeImage,
    jstring jlargeText,
    jstring jsmallImage,
    jstring jsmallText,
    jlong jstartEpoch) {

    if (!env || !jname || !jdetails || !jstate || !jlargeImage ||
        !jlargeText || !jsmallImage || !jsmallText) {
        notifyJava("PRESENCE_ERROR", "Invalid Rich Presence data");
        return JNI_FALSE;
    }

    const char* name = env->GetStringUTFChars(jname, nullptr);
    const char* details = env->GetStringUTFChars(jdetails, nullptr);
    const char* state = env->GetStringUTFChars(jstate, nullptr);
    const char* largeImage = env->GetStringUTFChars(jlargeImage, nullptr);
    const char* largeText = env->GetStringUTFChars(jlargeText, nullptr);
    const char* smallImage = env->GetStringUTFChars(jsmallImage, nullptr);
    const char* smallText = env->GetStringUTFChars(jsmallText, nullptr);

    if (!name || !details || !state || !largeImage || !largeText || !smallImage || !smallText) {
        if (name) env->ReleaseStringUTFChars(jname, name);
        if (details) env->ReleaseStringUTFChars(jdetails, details);
        if (state) env->ReleaseStringUTFChars(jstate, state);
        if (largeImage) env->ReleaseStringUTFChars(jlargeImage, largeImage);
        if (largeText) env->ReleaseStringUTFChars(jlargeText, largeText);
        if (smallImage) env->ReleaseStringUTFChars(jsmallImage, smallImage);
        if (smallText) env->ReleaseStringUTFChars(jsmallText, smallText);
        notifyJava("PRESENCE_ERROR", "Could not read Rich Presence strings");
        return JNI_FALSE;
    }

    bool queued = false;
    std::string error;

    try {
        std::lock_guard<std::mutex> lock(g_mutex);

        if (!g_client) {
            error = "Discord client is not initialized";
        } else {
            discordpp::Activity activity;
            activity.SetType(discordpp::ActivityTypes::Playing);
            activity.SetName(name);
            activity.SetDetails(details);
            activity.SetState(state);

            discordpp::ActivityAssets assets;
            if (largeImage[0] != '\0') assets.SetLargeImage(largeImage);
            if (largeText[0] != '\0') assets.SetLargeText(largeText);
            if (smallImage[0] != '\0') assets.SetSmallImage(smallImage);
            if (smallText[0] != '\0') assets.SetSmallText(smallText);
            activity.SetAssets(assets);

            discordpp::ActivityTimestamps timestamps;
            const jlong epoch = jstartEpoch > 0
                ? jstartEpoch
                : static_cast<jlong>(std::time(nullptr));
            timestamps.SetStart(static_cast<uint64_t>(epoch));
            activity.SetTimestamps(timestamps);

            // The Android RPC transport is asynchronous. Do not call
            // Connect(); SetApplicationId + UpdateRichPresence is the
            // supported unauthenticated Android flow in SDK 1.10+.
            g_client->UpdateRichPresence(
                std::move(activity),
                [](discordpp::ClientResult result) {
                    notifyJava(
                        result.Successful() ? "PRESENCE_OK" : "PRESENCE_ERROR",
                        result.ToString()
                    );
                }
            );
            queued = true;
        }
    } catch (const std::exception& e) {
        error = e.what();
        LOGE("UpdateRichPresence exception: %s", e.what());
    } catch (...) {
        error = "Unknown Discord SDK exception";
        LOGE("UpdateRichPresence unknown exception");
    }

    env->ReleaseStringUTFChars(jname, name);
    env->ReleaseStringUTFChars(jdetails, details);
    env->ReleaseStringUTFChars(jstate, state);
    env->ReleaseStringUTFChars(jlargeImage, largeImage);
    env->ReleaseStringUTFChars(jlargeText, largeText);
    env->ReleaseStringUTFChars(jsmallImage, smallImage);
    env->ReleaseStringUTFChars(jsmallText, smallText);

    if (!queued) {
        notifyJava("PRESENCE_ERROR", error.empty() ? "Presence request was not queued" : error);
    }

    return queued ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_nova_discordpresence_NativeBridge_stopPresence(JNIEnv*, jobject) {
    try {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (g_client) g_client->ClearRichPresence();
    } catch (...) {
        LOGE("ClearRichPresence failed");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_nova_discordpresence_NativeBridge_shutdown(JNIEnv*, jobject) {
    try {
        std::lock_guard<std::mutex> lock(g_mutex);
        if (g_client) {
            g_client->ClearRichPresence();
            g_client.reset();
        }
    } catch (...) {
        LOGE("Native shutdown failed");
        std::lock_guard<std::mutex> lock(g_mutex);
        g_client.reset();
    }
}
