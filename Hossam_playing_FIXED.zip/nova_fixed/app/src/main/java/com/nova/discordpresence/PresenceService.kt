package com.nova.discordpresence

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class PresenceService : Service() {

    data class Config(
        val name: String,
        val details: String,
        val state: String,
        val largeImage: String,
        val largeText: String,
        val smallImage: String,
        val smallText: String,
        val startEpoch: Long
    )

    companion object {
        @Volatile
        var currentConfig: Config? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            currentConfig?.let { c ->
                NativeBridge.startPresence(
                    c.name, c.details, c.state,
                    c.largeImage, c.largeText,
                    c.smallImage, c.smallText,
                    c.startEpoch
                )
            }
            handler.postDelayed(this, 20_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            "presence",
            "Hossam playing",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = Notification.Builder(this, "presence")
            .setContentTitle("Hossam playing")
            .setContentText("OneState • Rich Presence يعمل بالخلفية")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        startForeground(77, notification)
        handler.postDelayed(refresh, 20_000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            currentConfig = Config(
                intent.getStringExtra("name") ?: "OneState",
                intent.getStringExtra("details") ?: "Server : Fortuna ME",
                intent.getStringExtra("state") ?: "by Hossamat",
                intent.getStringExtra("largeImage") ?: "",
                intent.getStringExtra("largeText") ?: "",
                intent.getStringExtra("smallImage") ?: "",
                intent.getStringExtra("smallText") ?: "",
                intent.getLongExtra("startEpoch", System.currentTimeMillis() / 1000L)
            )
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
